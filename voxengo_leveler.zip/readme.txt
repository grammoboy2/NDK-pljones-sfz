Voxengo Leveler batch-processes the files selected and calculates weighted peak RMS.

To use: press Browse, select the file, then press Scan Folders and Process. After processing finishes you'll see a statistics window. The process is completely non-destructive.

Files can be arranged by name or by amplitude according to the checkbox.

Leveler works with both mono and stereo WAV files; peak RMS in stereo file is average for two channels.